// O(n)   complexity = log (n) = log(8) = 3    logM(N)
//                        3
#include <iostream>

using namespace std;

int main()
{
    cout<<"Hello World";
    
    int i,j,c=1,m,n,n1,m1,counter=1;
    
    cout<<"\nEnter n=";
    cin>>n;   
   
    
    for(i=0;i<=n;++i)
    {
    	cout<<endl<<"i="<<i<<" i<=n  n="<<n; 
    	cout<<endl<<"counter="<<counter;
        counter=counter+1;
        n=n/4;
    }

    return 0;
}
