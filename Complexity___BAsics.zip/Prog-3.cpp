// log(m)* log(n)
#include <iostream>

using namespace std;

int main()
{
    cout<<"Hello World";
    
    int i,j,c=1,m,n,n1,m1;
    
    cout<<"\nEnter m=";
    cin>>m;
    
    cout<<"\nEnter n=";
    cin>>n;
    n1=n;
    m1=m;    
    
    for(i=0;i<=m;++i)
    {                
        for(j=0;j<=n;++j)
        {        
        cout<<"\n i="<<i; 
		cout<<"\n j="<<j;     
        cout<<"\n counter="<<c;    c=c+1;
        n=n/2;    
        }
        n=n1;
        m=m/2;
    }

    return 0;
}
