// O(n)
#include <iostream>

using namespace std;

int main()
{
    cout<<"Hello World";
    
    int i,j,c=1,m,n,n1,m1,counter=1;
    
    cout<<"\nEnter n=";
    cin>>n;   
   
    
    for(i=1;i<=n;++i)
    {
    	cout<<endl<<counter;
        counter=counter+1;
    }

    return 0;
}
